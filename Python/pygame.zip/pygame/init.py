import pygame
import random

# Initialize Pygame
pygame.init()

# Set up the game window
WIDTH = 640
HEIGHT = 480
WINDOW = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Brick Breaker")

# Define game colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)

# Define game constants
BRICK_WIDTH = 60
BRICK_HEIGHT = 20
BRICK_PADDING = 10
BRICKS_PER_ROW = 10
NUM_ROWS = 5
PADDLE_WIDTH = 80
PADDLE_HEIGHT = 10
BALL_RADIUS = 8
BALL_SPEED = 5
SCORE_INCREMENT = 10
MAX_SCORE = BRICKS_PER_ROW * NUM_ROWS * SCORE_INCREMENT

# Load game fonts
FONT_SMALL = pygame.font.Font(None, 36)
FONT_LARGE = pygame.font.Font(None, 48)

# Define game objects
bricks = []
for i in range(NUM_ROWS):
    color = (random.randint(0, 255), random.randint(0, 255), random.randint(0, 255))
    for j in range(BRICKS_PER_ROW):
        x = j * (BRICK_WIDTH + BRICK_PADDING) + BRICK_PADDING
        y = i * (BRICK_HEIGHT + BRICK_PADDING) + BRICK_PADDING
        brick = pygame.Rect(x, y, BRICK_WIDTH, BRICK_HEIGHT)
        bricks.append((brick, color))
paddle = pygame.Rect(WIDTH / 2 - PADDLE_WIDTH / 2, HEIGHT - PADDLE_HEIGHT - 10, PADDLE_WIDTH, PADDLE_HEIGHT)
ball = pygame.Rect(WIDTH / 2 - BALL_RADIUS, HEIGHT / 2 - BALL_RADIUS, BALL_RADIUS * 2, BALL_RADIUS * 2)
ball_speed_x = random.randint(-BALL_SPEED, BALL_SPEED)
ball_speed_y = BALL_SPEED
score = 0

# Define helper functions
def draw_objects():
    WINDOW.fill(BLACK)

    # Draw bricks
    for brick, color in bricks:
        pygame.draw.rect(WINDOW, color, brick)

    # Draw paddle
    pygame.draw.rect(WINDOW, WHITE, paddle)

    # Draw ball
    pygame.draw.circle(WINDOW, WHITE, (ball.left + BALL_RADIUS, ball.top + BALL_RADIUS), BALL_RADIUS)

    # Draw score
    score_text = FONT_SMALL.render(f"Score: {score}", True, WHITE)
    score_rect = score_text.get_rect()
    score_rect.topright = (WIDTH - 10, 10)
    WINDOW.blit(score_text, score_rect)

    # Draw game over screen if the game is over
    if score >= MAX_SCORE:
        game_over_text = FONT_LARGE.render("GAME OVER", True, WHITE)
        game_over_rect = game_over_text.get_rect()
        game_over_rect.center = (WIDTH / 2, HEIGHT / 2)
        WINDOW.blit(game_over_text, game_over_rect)

    pygame.display.update()

def move_ball():
    ball.left += ball_speed_x
    ball.top += ball_speed_y

def reset_ball():
    ball.center = (WIDTH / 2, HEIGHT / 2)
    ball_speed_x = random.randint(-BALL_SPEED, BALL_SPEED)
    ball_speed_y = BALL_SPEED

# Game loop
clock = pygame.time.Clock()
while True:
    # Handle events
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()

    # Move the paddle
    keys = pygame.key.get_pressed()
    if keys[pygame.K_LEFT] and paddle.left > 0:
        paddle.left -= 5
    if keys[pygame.K_RIGHT] and paddle.right < WIDTH:
        paddle.left += 5

    # Move the ball
    move_ball()

    # Handle ball collisions with walls
    if ball.top <= 0:
        ball_speed_y = -ball_speed_y
    if ball.left <= 0 or ball.right >= WIDTH:
        ball_speed_x = -ball_speed_x
    if ball.bottom >= HEIGHT:
        reset_ball()
        score = 0

    # Handle ball collisions with paddle
    if ball.colliderect(paddle):
        ball_speed_y = -ball_speed_y

    # Handle ball collisions with bricks
    for i, (brick, color) in enumerate(bricks):
        if ball.colliderect(brick):
            del bricks[i]
            ball_speed_y = -ball_speed_y
            score += SCORE_INCREMENT

    # Draw game objects
    draw_objects()

    # Check if the game is over
    if score >= MAX_SCORE:
        pygame.time.delay(3000)
        bricks = []
        for i in range(NUM_ROWS):
            color = (random.randint(0, 255), random.randint(0, 255), random.randint(0, 255))
            for j in range(BRICKS_PER_ROW):
                x = j * (BRICK_WIDTH + BRICK_PADDING) + BRICK_PADDING
                y = i * (BRICK_HEIGHT + BRICK_PADDING) + BRICK_PADDING
                brick = pygame.Rect(x, y, BRICK_WIDTH, BRICK_HEIGHT)
                bricks.append((brick, color))
        paddle.left = WIDTH / 2 - PADDLE_WIDTH / 2
        ball_speed_x = random.randint(-BALL_SPEED, BALL_SPEED)
        ball_speed_y = BALL_SPEED
        score = 0

    # Update the game clock
    clock.tick(60)

# Quit Pygame
pygame.quit()
