# from PIL import ImageGrab
# from PIL import ImageFilter
# import pygame

# # take screenshot of the screen
# screenshot = ImageGrab.grab()

# # blur the screenshot
# blurred_screenshot = screenshot.filter(ImageFilter.GaussianBlur(radius=10))

# # convert the blurred image to a pygame surface
# pygame_blurred_screenshot = pygame.image.frombuffer(blurred_screenshot.tobytes(), blurred_screenshot.size, blurred_screenshot.mode)
# # display the blurred screenshot surface
# screen.blit(pygame_blurred_screenshot, (0,0))



# import pygame
# from PIL import ImageGrab, ImageFilter

# pygame.init()

# # set up the Pygame window
# screen_width = 640
# screen_height = 480
# screen = pygame.display.set_mode((screen_width, screen_height))

# # take screenshot of the screen
# screenshot = ImageGrab.grab(bbox=None)

# # blur the screenshot
# blurred_screenshot = screenshot.filter(ImageFilter.GaussianBlur(radius=10))

# # convert the blurred image to a pygame surface
# pygame_blurred_screenshot = pygame.image.frombuffer(blurred_screenshot.tobytes(), blurred_screenshot.size, blurred_screenshot.mode)

# # game loop
# running = True
# while running:
#     # handle events
#     for event in pygame.event.get():
#         if event.type == pygame.QUIT:
#             running = False
    
#     # display the blurred screenshot surface
#     screen.blit(pygame_blurred_screenshot, (0,0))
    
#     # update the display
#     pygame.display.update()

# pygame.quit()

# Importing Image and ImageGrab module from PIL package
# from PIL import Image, ImageGrab
	
# # creating an image object
# im1 = Image.open('./images/save_btn.png')
	
# # using the grab method
# im2 = ImageGrab.grab(bbox = None)
	
# im2.show()

# import cv2
# import mss
# import numpy as np
# import pygame

# pygame.init()

# # set up the Pygame window
# screen_width = 640
# screen_height = 480
# screen = pygame.display.set_mode((screen_width, screen_height))

# # create a screenshot object
# with mss.mss() as sct:
#     screenshot = sct.grab(sct.monitors[1])

# # convert the screenshot to a numpy array
# screenshot = np.array(screenshot)

# # blur the screenshot
# blurred_screenshot = cv2.GaussianBlur(screenshot, (25, 25), 0)

# # convert the blurred image to a Pygame surface
# pygame_blurred_screenshot = pygame.surfarray.make_surface(blurred_screenshot)

# # game loop
# running = True
# while running:
#     # handle events
#     for event in pygame.event.get():
#         if event.type == pygame.QUIT:
#             running = False
    
#     # display the blurred screenshot surface
#     screen.blit(pygame_blurred_screenshot, (0,0))
    
#     # update the display
#     pygame.display.update()

# pygame.quit()

import pygetwindow
import pyautogui
from PIL import Image

path = "./images/result.png"
titles = pygetwindow.getAllTitile()